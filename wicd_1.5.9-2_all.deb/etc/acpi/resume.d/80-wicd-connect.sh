#!/bin/sh
# Bring wifi network interface back up.

/usr/share/wicd/autoconnect.py
